<?php
/**
 * Plantilla para mostrar el Error 404.
 */

// Cabecera
get_header(); ?>

<div>
	<p>
		<?php echo __('Error 404', 'think-appart'); ?>
	</p>
</div>

<?php
// Footer
get_footer();